package com.dal;

public interface EmployeeInterface {
	public void AddEmployee();
	public void ViewEmployee();
}
